warning('off', 'MATLAB:nearlySingularMatrix');
warning('off', 'MATLAB:singularMatrix');

files = dir(fullfile('netlib\*.mat'));
fprintf('%10s %8s %8s %10s %5s %12s %14s\n', 'name', 'm', 'n', 'nnz', 'iter', 'time', 'OPT')
for k = 1:length(files)
    load(strcat('netlib\', files(k).name), 'Problem');
    Problem = splitDenseCols(Problem, 12);
    [A,b,c,c0] = standardForm(Problem);
    
    tic;
    % perturb the cost so that the solution set is bounded.
    [x,iter] = solveLP(A,b,c + 1e-7*mean(abs(c)));
    opt = sum(c.*x) + c0;
    t = toc;
    
    fprintf('%10s %8i %8i %10i %5i %12f %14e\n', files(k).name(4:end-4), size(A,1), size(A,2), nnz(A), iter, t,  opt)
end
