% input is an LP given by min <c,x> subjects to Ax=b, l<=x<=u
% output is an equivalent LP given by min <c,x> + c0 subjects to Ax=b, x>=0
function [A,b,c,c0] = standardForm(Problem)
A = sparse(Problem.A);
b = Problem.b;
c = Problem.aux.c;
lo = Problem.aux.lo;
hi = Problem.aux.hi;

% split free variables x
free_idx = ((hi == Inf) & (lo == -Inf));
free_cnt = sum(free_idx);
m = size(A,1);
n = size(A,2);
A = [A -A(:,free_idx)];
c(end+1:end+free_cnt) = - c(free_idx);
c(free_idx) = c(free_idx);
lo(free_idx) = 0;
lo(end+1:end+free_cnt) = 0;
hi(end+1:end+free_cnt) = Inf;

% flip the constraint x <= u to -x>= -u
hi_only_dx = ((hi ~= Inf) & (lo == -Inf));
lo(hi_only_dx) = -hi(hi_only_dx);
hi(hi_only_dx) = Inf;
A(:,hi_only_dx) = -A(:,hi_only_dx);       % x_new = -x (for hi_only)
c(hi_only_dx) = -c(hi_only_dx);

% shift the lo to 0
lo_idx = (lo ~= -Inf);
hi(lo_idx) = hi(lo_idx) - lo(lo_idx);     % x_new = x - lo  (for lo)
b = b - A*(lo.*lo_idx);
c0 = -sum(c(lo_idx).*lo(lo_idx));

% split idx with both hi and lo constraints
hi_lo_idx = ((hi ~= Inf) & (lo ~= -Inf));
hi_lo_cnt = sum(hi_lo_idx);
m = size(A,1);
n = size(A,2);
A = [A sparse(m,hi_lo_cnt); sparse(hi_lo_cnt, n) speye(hi_lo_cnt,hi_lo_cnt)];
A(m+1:m+hi_lo_cnt, hi_lo_idx) = speye(hi_lo_cnt,hi_lo_cnt);
b(end+1:end+hi_lo_cnt) = hi(hi_lo_idx);  % create new variables x + x_new = hi
c(end+1:end+hi_lo_cnt) = 0;
end
