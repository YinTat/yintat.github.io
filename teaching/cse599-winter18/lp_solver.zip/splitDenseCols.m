% input is an LP given by min <c,x> subjects to Ax=b, l<=x<=u
% output is an equivalent LP in same form but without cols with more than
% maxNZ non-zeros.
function Problem = splitDenseCols(Problem, maxNZ)
A = Problem.A;
b = Problem.b;
c = Problem.aux.c;
hi = Problem.aux.hi;
lo = Problem.aux.lo;

nzCounts = full(sum(A~=0,1));
while max(nzCounts)>maxNZ
    [m,n] = size(A);
    GoodCols = find(nzCounts <= maxNZ);
    BadCols = find(nzCounts > maxNZ);
    numBadCols = length(BadCols);
    
    newA = spalloc(m, numBadCols, sum(nzCounts));
    
    counter = 1;
    for i = BadCols
      nzIndices = find(A(:,i));
      midpoint = nzIndices(floor(length(nzIndices)/2));
      last = nzIndices(end);
      newA(midpoint+1:last, counter) = A(midpoint+1:last,i);
      A(midpoint+1:last,i) = 0;
      counter = counter+1;
    end
    
    A = [A newA];
    A = [A; sparse(numBadCols, n) -speye(numBadCols,numBadCols)];
    b = [b; zeros(numBadCols,1)];
    A(m+1:m+numBadCols,BadCols) = speye(numBadCols,numBadCols);
    c = [c; zeros(numBadCols,1)];
    hi = [hi; hi(BadCols)];
    lo = [lo; lo(BadCols)];
    
    nzCounts = full(sum(A~=0,1));
end


Problem.A = A;
Problem.b = b;
Problem.aux.c = c;
Problem.aux.hi = hi;
Problem.aux.lo = lo;
end