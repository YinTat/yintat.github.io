% This is an implementation of Mehrotra's predictor-coorector algorithm.
% We solve the linear program min <c,x> subject to Ax=b, x>=0
function [x, iter] = solveLP(A, b, c)
m = size(A,1);  n = size(A,2); maxiter = 100;
P = colamd(A');
A = A(P,:);     b = b(P);

% Find an initial point
R = builtin('_cholinf', A * A');
y = R\(R'\(A*c));   s_ = c - A' * y;    x_ = A' * (R\(R'\b));
dx = max(-1.5 * min(x_), 0);     ds = max(-1.5 * min(s_), 0);
x = x_ + dx + 0.5 * ((x_ + dx)' * (s_+ds))/sum(s_+ds);
s = s_ + ds + 0.5 * ((x_ + dx)' * (s_+ds))/sum(x_+dx);
nb = mean(abs(b));

for iter = 1:maxiter
    mu = sum(x.*s)/n;
    rb = A * x - b;     rc = A' * y + s - c;    rxs = x .* s;
    if mu < 1e-6 && mean(abs(rb)) < 1e-6 * nb, break; end
    
    R = builtin('_cholinf', A * diag(sparse(x./s)) * A');
    [dx_a, dy_a, ds_a] = step_dir(A, R, x, s, rc, rb, rxs);
    
    xa_step = dist(x, dx_a);	sa_step = dist(s, ds_a); 
    mu_a = sum((x+xa_step*dx_a).*(s+sa_step*ds_a))/n;
    sigma = min((mu_a/mu)^3,1);
    
    rxs = -(sigma * mu - dx_a .* ds_a);
    [dx_c, dy_c, ds_c] = step_dir(A, R, x, s, zeros(n,1), zeros(m,1), rxs);
    
    dx = dx_a + dx_c;   dy = dy_a + dy_c;   ds = ds_a + ds_c;
    x_step = min(0.99*dist(x, dx),1);
    s_step = min(0.99*dist(s, ds),1); 
    
    x = x + x_step * dx; y = y + s_step * dy; s = s + s_step * ds;
end
if iter == maxiter, x = ones(n,1) * NaN; end % x = NaN if doesn't converge.
end
% This outputs the solution of the linear system
% [0 A' I; A 0 0 ;S 0 X][dx;dy;ds] = [-rc, -rb, -rxs]
% The chol decomposition of A S^-1 X A' = R' R is given
function [dx, dy, ds] = step_dir(A, R, x, s, rc, rb, rxs)
    r = - rb + A * ((-x.*rc+rxs)./s);
    dy = R\(R'\r);  ds = -rc - A' * dy; dx = -(rxs + x .* ds)./s;
end
function [step] = dist(x, dx)
    step = -x./dx;
    step(dx>=0) = Inf;
    step = min(step);
end